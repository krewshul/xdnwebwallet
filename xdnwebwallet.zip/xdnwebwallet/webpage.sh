#!/bin/bash

plot.py > /var/www/html/masternodelist.txt

sleep 2

./python_rpc_script.py

sleep 2
