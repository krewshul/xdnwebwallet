#!/usr/bin/python

import pandas as pd
import plotly
import numpy
from bitcoinrpc.authproxy import AuthServiceProxy
import jsonrpc
import time

access = AuthServiceProxy("http://krew:fuck@127.0.0.1:8332")
master = access.masternodelist()

for x in master: print(x) + ":Enabled"


